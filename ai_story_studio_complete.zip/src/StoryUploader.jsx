import React from 'react';
export default function StoryUploader() { return <div>Hikaye yükleyici</div>; }